# ***********************************************************************************************************************
# *                                                                                                                     *
# *   MainWindow.py                                                                                                     *
# *   Authors: Robert B. Wilson, Alex Baker, Jordan Phillips, Gabriel Snider, Steven Dorsey, Yoshinori Agari            *
# *   The purpose of this file is to load the MainWindow UI file upon initialization and also provide logic for         *
# *   all of the widgets used throughout the MainWindow UI                                                              *
# *                                                                                                                     *
# ***********************************************************************************************************************

import PyQt5
from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import *
import sys
from classes.Database import Database
from classes.User import User

class MainWindow(QtWidgets.QMainWindow):
    # Function: Constructor
    # Parameters: None
    # Return: MainWindow UI object
    # Loads the MainWindow.UI file and initializes all of the widget logic
    def __init__(self):
        # Call QMainWindow Constructor
        super(MainWindow, self).__init__()
        # Load MainWindow.UI
        uic.loadUi(r"./views/MainWindow.ui", self)
        # Initialize User
        self.User = User()
        # Load Widgets
        self.Admin_Button = self.findChild(QtWidgets.QLabel, "Admin_Button")
        self.Stacked_Widget = self.findChild(QtWidgets.QStackedWidget, "stackedWidget")
        self.Login_Button = self.findChild(QtWidgets.QPushButton, "Login_Button")
        self.Username_LineEdit = self.findChild(QtWidgets.QLineEdit, "Username_LineEdit")
        self.Password_LineEdit = self.findChild(QtWidgets.QLineEdit, "Password_LineEdit")

        # Connect Event Logic
        self.Admin_Button.mousePressEvent = self.Admin_Button_Logic
        self.Login_Button.clicked.connect(self.Login_Button_Logic)

        # Initialize default Stacked Widget Page
        self.Stacked_Widget.setCurrentIndex(0)
        # Display Window
        self.show()
    


    # Function: Admin_Button_Logic
    # Parameters: mousePressedEvent
    # Return: None
    # Checks if a user has been logged in, if yes --> it changes the current stacked widget index to the admin page. If no --> it changes the current stacked widget index to the login page.
    def Admin_Button_Logic(self, event):
        # case user is at the home page and not logged in
        if self.Stacked_Widget.currentIndex() == 0 and not self.User.isAuthenticated:
            self.Stacked_Widget.setCurrentIndex(1)
            self.Admin_Button.setText("Home")
        # case user is at the home page and are logged in
        elif self.Stacked_Widget.currentIndex() == 0 and self.User.isAuthenticated:
            self.Stacked_Widget.setCurrentIndex(2)
            self.Admin_Button.setText("Home")
        # case user is at the login page
        elif self.Stacked_Widget.currentIndex() == 1:
            self.Stacked_Widget.setCurrentIndex(0)
            self.Admin_Button.setText("Admin")
        # case user is at the admin page
        else:
            self.Stacked_Widget.setCurrentIndex(0)
            self.Admin_Button.setText("Admin")
    


    # Function: Login_Button_Logic
    # Parameters: None
    # Return: None
    # Fetches text from Username and Pwssword QLineEdit Widgets and attempts to authenticate the user based on this data. If the user is authenticated, the user will be redirected to the admin page. Otherwise a invalid login notification will be displayed.
    def Login_Button_Logic(self):
        # get username and password claims
        username = self.Username_LineEdit.text()
        password = self.Password_LineEdit.text()
        # attemo to authenticate
        if self.User.authenticate(username, password):
            # update widgets and redirect to admin page
            self.Stacked_Widget.setCurrentIndex(2)
            self.Admin_Button.setText("Home")
            self.setWindowTitle("SFTPPipeline - Welcome " + self.User.Username)
        else:
            # display login error notification
            self.Username_LineEdit.setText("")
            self.Password_LineEdit.setText("")
        

#app = QApplication(sys.argv)
#window = MainWindow()
#app.exec_()